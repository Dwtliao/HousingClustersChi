
library(psych)
library(stats)
library(plyr)
library(MASS)
library(leaps)
library(car)
library(corrplot)
library(ggplot2)
library(cluster)   #for clusplot
library(data.table)
library(knitr)
library(dplyr)
library(VIM)
library(clusterCrit)  #Compute Internal Validation Indexes of Clusters


##->  REading data and prepare 2 dataframes - 2013 vs Chg data -----------
#setwd("C:/Users/David/Google Drive/IHS_CMAP/MasterFiles/Feb5/") 
setwd("C:/Users/dliao/Google Drive/IHS_CMAP/MasterFiles/Mar7_ReclustFiles/")
#filePath <- "MasterFile_1980.csv"    #1980 tract rows
filePath <- "MasterFile_Mar7.csv"    #1980 tract rows
CSV_file <- read.csv(filePath, head=TRUE, sep=",", stringsAsFactors = F) 

#cmap2013.df = CSV_file[, c(1, 6, 8, 10, 12:22, 24, 26, 28, 30:32, 34, 36, 38, 40,
#                           42, 44, 46:47, 53:57, 59, 61, 63:64, 67, 69, 71, 73:76,84, 86)]  

#chg00_13.df = CSV_file[, c(1, 3, 5, 7, 9, 11, 23, 25, 27, 29, 30:31, 33, 35, 37, 39,
#                           41, 43, 45, 48:52, 58, 60, 62, 65:66, 68, 70, 72, 77:83, 85, 87:90, 99)]   

cmap2013.df = CSV_file[, c(1, 6, 8, 10, 12:22, 24, 26, 28, 30:32, 34, 36, 38, 40,
                           42, 44, 46:47, 53:57, 59, 61, 63:64, 67, 69, 71, 73:76,84, 86, 91:95, 100:103, 112:113)]  

chg00_13.df = CSV_file[, c(1, 3, 5, 7, 9, 11, 23, 25, 27, 29, 30:31, 33, 35, 37, 39,
                           41, 43, 45, 48:52, 58, 60, 62, 65:66, 68, 70, 72, 77:83, 85, 87:90, 99, 104:105 )]       


#remove desire variables from  datasets 
cmap2013.df$Y13_MedGrRent_Scaled <- NULL
cmap2013.df$Y13_PCT_HUnits_CostBurden_LT30 <- NULL
cmap2013.df$Y14PCT_Renter_Moved1980to1999 <- NULL
cmap2013.df$Y14_PCT_OtherRace_Alone <- NULL
cmap2013.df$Y14_PCT_Not_Hispanic_or_Latino_Total <- NULL
cmap2013.df$Y14_PCT_Two_or_More_Races <- NULL
cmap2013.df$Y13_PCT_OwnerCount <- NULL
cmap2013.df$Y13_MedGrRent_Scaled <- NULL
cmap2013.df$Scaled_PopDensity2013 <- NULL
cmap2013.df$Y13_PCT_HUnits_CostBurden_LT30 <- NULL
cmap2013.df$Y14PCT_Renter_Moved2000to2010_orLater  <- NULL
cmap2013.df$Share_Res_Sales_BizBuyer <- NULL
cmap2013.df$Scaled_SFamily_MedianSaleAmt_7Ctys <- NULL
cmap2013.df$HUD_Total_Units <- NULL

cmap2013.missv = aggr(cmap2013.df, prop=FALSE, numbers=TRUE)
summary(cmap2013.missv)

chg00_13.df$Chg_PCT_MedGrossRent <- NULL
chg00_13.df$OwnerChange <- NULL
chg00_13.df$Change_CostBurden_LTE30 <- NULL
chg00_13.df$Chg_Scaled_PopDensity <- NULL
chg00_13.df$HUD_Housing_Pct_of_HHIncome_hh_h <- NULL
chg00_13.df$HUD_Transportation_Pct_of_HHIncome_hh_t <- NULL
chg00_13.df$Chg_PCT_Not_Hispanic_or_Latino  <- NULL
chg00_13.df$Chg_PCT_OtherRace_Alone   <- NULL
chg00_13.df$Chg_PCT_Two_or_More_Races  <- NULL
chg00_13.df$Scaled_HUDensity2000  <- NULL
#chg00_13.df$Chg_HUDensity  <- NULL

chg00_13.missv = aggr(chg00_13.df, prop=FALSE, numbers=TRUE)
summary(chg00_13.missv)

##-- Create separate dataframe for 2013 vs Chg -------
km13.data = data.table(cmap2013.df)
kmchg.data = data.table(chg00_13.df)

#set all NA values to 0 or -1
#km13.data[is.na(km13.data)] = -1
#ignore tracts with missing values
km13.data = na.omit(km13.data)
km13.bkp = km13.data
km13.data$CensusTract <- NULL

##--- omitting NA rows excludes tracts for analysis 
#kmchg.data[is.na(kmchg.data)] = -1

kmgchg.nasbset = na.omit(kmchg.data, invert=TRUE)
kmchg.data = na.omit(kmchg.data)
kmchg.bkp = kmchg.data
kmchg.data$CensusTract <- NULL

##-- Prepare PAM cluster objs for Chg data & 2013 data
set.seed(1234)

##---Install CLUE for Ensemble Clustering ------------
library(clue)
library(pryr)  #-- check out oo obj classes

set.seed(1234)

##-- cl_bag does not allow choice of consensus function to decide how to vote results into 
##-- membership table across the # of bootstrap replicates specified
##-- consensus vote is algorithm "BagClust1" in Dudoit & Fridlyand (2003).

bagm8Chg_100=cl_bag(kmchg.data, 100, 8, "pam")
bagm8Chg_50 =cl_bag(kmchg.data,  50, 8, "pam")
summary(bagm8Chg_50)

bagm8_50=cl_bag(km13.data, 50, 8, "pam")
bagm8_100=cl_bag(km13.data, 100, 8, "pam")



##- extract membership table from bagging run ------
consModel = bagm8Chg_50   #CHG data
clustSizes <- table(cl_class_ids(consModel))
clustSizes

bag.membership <- as.cl_membership(consModel)

##- turn membership probabilities into data frame, each column is a cluster
bag.memberDf <- data.frame(c1prob=bag.membership[,1], c2prob=bag.membership[,2],
                              c3prob=bag.membership[,3], c4prob=bag.membership[,4],
                              c5prob=bag.membership[,5], c6prob=bag.membership[,6],
                              c7prob=bag.membership[,7], c8prob=bag.membership[,8])

##-- apply definition of weak membership for rows with split vote ----
bag.memberDf$isWeak <- apply(bag.memberDf, 1, function(x) max(x) < .5)
##- Count how many rows have weak membership
modelWeak <- sum(bag.memberDf$isWeak)
modelWeak

##- resolve membership probabilities and assign each row a hard cluster number------
bag.memberDf$hardClus <- as.factor(as.cl_hard_partition(consModel)$.Data)
##- Number of rows per cluster 
summary(bag.memberDf$hardClus)

##-- Add census tract into membership table
##-- ONLY do this AFTER the weak membership is calculated and Hard Cluster is done----
bag.memberDf$tract <-  kmchg.bkp$CensusTract   #YCHG data

##-- compute a few internal indexes -----------
bagm8.CHG.IntIDX= intCriteria(as.matrix(kmchg.data), 
                              as.integer(bag.memberDf$hardClus),
                              c("Dunn", "Calinski_Harabasz", "Silhouette", "Davies_Bouldin","Xie_Beni", "SD_Dis"))
bagm8.CHG.IntIDX








##-- Example of using cl_boot with specific consensus function -----------------
##- use cl_boot to create bootstrap replicates of base clustering algorithm
set.seed(1234)
bootLloyd <- cl_boot(kmchg.data, 50, 8, "kmeans", parameters=c(nstart=2, 
                                                               algorithm="Lloyd", 
                                                               iter.max=100))

##- choose consensus vote method to create membership table across bootstrap replicates above
bootLloyd.cons <- cl_consensus(bootLloyd, method = "SE")


#- extract membership table 
bootCons.membership <- as.cl_membership(bootLloyd.cons)
##- turn membership probabilities into data frame, each column is a cluster
bootCons.memberDf <- data.frame(c1prob=bootCons.membership[,1], 
                                c2prob=bootCons.membership[,2],
                                c3prob=bootCons.membership[,3], 
                                c4prob=bootCons.membership[,4],
                                c5prob=bootCons.membership[,5], 
                                c6prob=bootCons.membership[,6],
                                c7prob=bootCons.membership[,7], 
                                c8prob=bootCons.membership[,8])

##-- apply definition of weak membership for rows with split vote ----
bootCons.memberDf$isWeak <- apply(bootCons.memberDf, 1, function(x) max(x) < .5)
##- Count how many rows have weak membership
modelWeak <- sum(bootCons.memberDf$isWeak)
modelWeak

##- resolve membership probabilities and assign each row a hard cluster number------
bootCons.memberDf$hardClus <- as.factor(as.cl_hard_partition(bootLloyd.cons)$.Data)
##- Number of rows per cluster 
summary(bootCons.memberDf$hardClus)


##-- Add census tract into membership table
##-- ONLY do this AFTER the weak membership is calculated and Hard Cluster is done----
bootCons.memberDf$tract <-  kmchg.bkp$CensusTract   #YCHG data


##-- compute a few internal indexes -----------

bootkm8.CHG.IntIDX= intCriteria(as.matrix(kmchg.data), 
                              as.integer(bootCons.memberDf$hardClus),
                              c("Dunn", "Calinski_Harabasz", "Silhouette", "Davies_Bouldin","Xie_Beni", "SD_Dis"))
bootkm8.CHG.IntIDX
